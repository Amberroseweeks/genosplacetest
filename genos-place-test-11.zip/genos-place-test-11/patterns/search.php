<?php
/**
 * Title: Search page block pattern
 * Slug: genos-place-test/search
 * Categories: featured
 * inserter: no
 *
 * @package genos-place-test
 * @since 1.0.0
 */

?>
<!-- wp:heading {"className":"is-style-genos-place-test-text-shadow","fontSize":"x-large"} -->
<h2 class="is-style-genos-place-test-text-shadow has-x-large-font-size">
<?php echo genos_place_test_search_title(); ?></h2><!-- /wp:heading -->

